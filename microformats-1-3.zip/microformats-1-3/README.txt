Microformats 1.3
================

Hello. Thank you for downloading the Microformats plug-in for Coda 2.

This plugin allows you to create hCard, hCalendar and now hReview micro formats using a simple set of forms.

Fill out the fields and you will get HTML markup with the appropriate CSS classes for the micro format you choose.

The HTML is meant as a starting point for you to customize as you see fit, however, if the HTML serves your needs, please feel free to use it.

You can use this plug-in via the Plug-ins menu item in Coda 2 or by pressing Control-Option-Command-M on your keyboard.


Installation
============

For best result, please do the following:

1. Close Coda 2
2. Open Coda 2
3. Double-click not the "Microformats.codaplugin" file

You should find the "Insert Microformat…" option under the Plug-ins menu item in Coda 2.


Uninstallation
==============

For best result, please do the following:

1. Close Coda 2
2. In Finder, navigate to: /Users/YOUR USER DIRECTORY/Library/Application Support/Coda 2/Plug-ins/
3. Select the "Microformats.codaplugin" file and move it to the Trash
4. Open Coda 2


Problems or Questions
=====================

If you run into any issues using this plug-in or just have general comments or recommendations, please contact me @joedakroub via Twitter or joe.dakroub@me.com.


License
=======

Microformats is distributed under The MIT License (MIT). Please refer to 'LICENSE' file for more information.


Changelog
=========

Version 1.3

* Added the ability to add a contact from the Address Book into the Card form
* Set plug-in up for localization

Version 1.2.1

* Changed Country field to a pop-up menu

Version 1.2

* Added hReviews

Version 1.1.2

* Now compiled to run on Mac OS X 10.6

Version 1.1.1

* Fixed the order in which tabbing through the fields works on the Card tab

Version 1.1

* The "Insert Microformat…" option is now only enabled in the code editor view

Version 1.0

* Initial release