Task Timer 1.0.1
================

Hello. Thank you for downloading the Task Timer plug-in for Coda 2.

This is a simple little timer plug-in that follows the basic principles of The Pomodoro Technique (http://www.pomodorotechnique.com).

The idea is simple: 

1. Start the timer and work for 25 minutes
2. After the timer goes off, you will hear whatever voice you set up in System Preferences  tell you that it is time to take a 5 minute break
3. Take a 5 minute break
4. After 4 iterations of 25 minutes, you can take a 20 minute break.

The concept here is to help you focus on your work for a short, but effective period of time. The 5 minute break helps your mind and body assimilate the work you just completed.

This plug-in does not aim to capture everything the technique promotes (recording completed activities with an X or noting interruptions with, etc.).

In addition, there is a constant tick-tock sound that plays while you work. You can mute this with your keyboard, but I would advise to try and use the sound to your advantage. Often times it can actually help your concentration and aid you in your desire to complete the task.

Please note, if you click the Stop button, the timer starts over at 25 minutes. This is intentional behavior.

Please see http://www.pomodorotechnique.com for more information about this technique.

May you be more productive and healthier in your work!


Installation
============

For best result, please do the following:

1. Close Coda 2
2. Open Coda 2
3. Double-click not the "Task Timer.codaplugin" file

You should find the "Task Timer" option under the Plug-ins menu item in Coda 2.


Uninstallation
==============

For best result, please do the following:

1. Close Coda 2
2. In Finder, navigate to: /Users/YOUR USER DIRECTORY/Library/Application Support/Coda 2/Plug-ins/
3. Select the "Task Timer.codaplugin" file and move it to the Trash
4. Open Coda 2


Problems or Questions
=====================

If you run into any issues using this plug-in or just have general comments or recommendations, please contact me @joedakroub via Twitter or joe.dakroub@me.com.


License
=======

BWToolkit is distributed under BSD license. Please refer to 'LICENSE' file for more information.


Credits
=======

Task Timer makes use of the amazing BWToolkit by Brandon Walkin.

BWToolkit: BWToolkit is an Interface Builder plugin that contains commonly used UI elements and other objects designed to simplify Mac development. (http://brandonwalkin.com/bwtoolkit/)

Licenses for this library have been included in the 'licenses' directory of this distribution. 


Changelog
=========

Version 1.0.1

* Minor bug fixes

Version 1.0

* Initial release