HTML Entities 1.1.2
===================

Hello. Thank you for downloading the HTML Entities plug-in for Coda 2.

Coda 2 features an option under the Text > Processing menu to encode entities.

In addition you can find the Special Characters palette under the Edit menu or by pressing Option-Command-T.

This plug-in uses these two features to automatically encode any special characters into an HTML entity.

To use it you can do the following:

1. Press Option-Command-T
2. Double-click on a special character that you wish to encode
3. There is no step 3!

Whatever characters that Coda's "Encode Entities" menu item encodes will get encoded directly in your editor.

This functionality is ONLY available for HTML and XML documents.

The Special Characters palette functions as it normally does for all other document formats.

This plug-in is extremely alpha and as such has some quirks:

- When using undo on an encoded character you will see the raw special character in its place. You will have to undo again to get back to the state before you entered the raw character. I am looking into this.

- The speed of your editor MAY be impacted. I have not noticed a slowdown, but my testing has been brief thus far.

- The editor MAY crash. If you notice an increase in crashes since installing this plug-in, I would blame the plug-in, NOT Coda. If you do receive a crash and can capture the crash log, please send it to me. It will help me in debugging the plug-in.

- The following HTML entities do NOT get encoded: < > & " '. This is because they are used in writing HTML and XML, so encoding them would be counter-productive.

- Greek characters and other accented characters do NOT get encoded as those characters are used on non-English keyboards and would not make sense to be encoded.


Installation
============

For best result, please do the following:

1. Close Coda 2
2. Open Coda 2
3. Double-click not the "HTML Entities.codaplugin" file

You can now use the Special Characters map via the Edit menu or by pressing Option-Command-T.


Uninstallation
==============

For best result, please do the following:

1. Close Coda 2
2. In Finder, navigate to: /Users/YOUR USER DIRECTORY/Library/Application Support/Coda 2/Plug-ins/
3. Select the "HTML Entities.codaplugin" file and move it to the Trash
4. Open Coda 2


Problems or Questions
=====================

If you run into any issues using this plug-in or just have general comments or recommendations, please contact me @joedakroub via Twitter or joe.dakroub@me.com.


License
=======

HTML Entities is distributed under The MIT License (MIT). Please refer to 'LICENSE' file for more information.


Changelog
=========

Version 1.1.2

* Now compiled to run on Mac OS X 10.6

Version 1.1.1

* Fixed a potential crashing bug - yes, this is still alpha!

Version 1.1

* Fixed a bug where plug-in would encode characters for non-HTML/XML documents

Version 1.0

* Initial release