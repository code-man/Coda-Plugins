Web Sharing 1.1
===============

Hello. Thank you for downloading the Web Sharing plug-in for Coda 2.

This plugin allows you to quickly enable and disable the Apple Web Sharing (Apache) system by flicking the Yes/No switch. No more, no less.

Please note, in OS 10.8 (Mountain Lion), Apple removed Web Sharing from the System Preferences. If you are on a new machine or a fresh install, you may have to do more setup to get Apache fully functioning before this plug-in will work.

Please see this article for very detailed information on getting Web Sharing restored:

http://reviews.cnet.com/8301-13727_7-57481978-263/how-to-enable-web-sharing-in-os-x-mountain-lion/

Once you follow these steps, Web Sharing should function normally.

You can use this plug-in via the Plug-ins menu item in Coda 2 or by pressing Control-Option-Command-W on your keyboard.


Installation
============

For best result, please do the following:

1. Close Coda 2
2. Open Coda 2
3. Double-click not the "Web Sharing.codaplugin" file

You should find the "Web Sharing" option under the Plug-ins menu item in Coda 2.


Uninstallation
==============

For best result, please do the following:

1. Close Coda 2
2. In Finder, navigate to: /Users/YOUR USER DIRECTORY/Library/Application Support/Coda 2/Plug-ins/
3. Select the "Web Sharing.codaplugin" file and move it to the Trash
4. Open Coda 2


Problems or Questions
=====================

If you run into any issues using this plug-in or just have general comments or recommendations, please contact me @joedakroub via Twitter or joe.dakroub@me.com.


License
=======

Web Sharing is distributed under The MIT License (MIT). Please refer to 'LICENSE' file for more information.


Changelog
=========

Version 1.1

* Switch will now reflect the actual status of Apache even if you manually start/stop/restart it from Terminal or other apps.

Version 1.0

* Initial release